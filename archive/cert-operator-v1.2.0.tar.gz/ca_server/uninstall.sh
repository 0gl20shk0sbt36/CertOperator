#!/bin/bash
# =============================================================================
# cert-operator 服务端卸载脚本
# 停止服务 → 删除文件 → 删除用户 → 清理 systemd
# =============================================================================
set -euo pipefail

# ---- 颜色 ----
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
err()   { echo -e "${RED}[ERR]${NC} $*" >&2; }

if [[ $EUID -ne 0 ]]; then
    err "请以 root 身份运行此脚本"
    exit 1
fi

INSTALL_DIR="/opt/ca_server"
SERVICE_NAME="cert-operator"
SERVICE_USER="cert-operator"

# --yes 参数跳过确认（供 install.sh --clean 调用）
FORCE=0
KEEP_FILES=0
for arg in "$@"; do
    [[ "$arg" == "--yes" ]] && FORCE=1
    [[ "$arg" == "--keep-files" ]] && KEEP_FILES=1
done

if [[ $FORCE -eq 0 ]]; then
    echo ""
    echo "============================================================"
    echo -e "${RED}  卸载 cert-operator CA 服务器${NC}"
    echo "============================================================"
    echo ""
    echo "将执行以下操作："
    echo "  - 停止并禁用 $SERVICE_NAME 服务"
    echo "  - 删除 /etc/systemd/system/${SERVICE_NAME}.service"
    echo "  - 删除 $INSTALL_DIR"
    echo "  - 删除系统用户 $SERVICE_USER"
    echo ""
    read -r -p "确认卸载？(y/N): " confirm
    if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
        info "已取消"
        exit 0
    fi
fi

# ---- 1. 停止并禁用服务 ----
if systemctl list-unit-files --quiet "$SERVICE_NAME.service" 2>/dev/null; then
    info "停止并禁用服务..."
    systemctl stop "$SERVICE_NAME" 2>/dev/null || true
    systemctl disable "$SERVICE_NAME" 2>/dev/null || true
    rm -f "/etc/systemd/system/${SERVICE_NAME}.service"
    systemctl daemon-reload 2>/dev/null || true
    info "服务已清理"
fi

# ---- 2. 删除安装目录 ----
if [[ $KEEP_FILES -eq 0 ]] && [[ -d "$INSTALL_DIR" ]]; then
    info "删除 $INSTALL_DIR ..."
    rm -rf "$INSTALL_DIR"
    info "安装目录已删除"
fi

# ---- 3. 删除专用用户（--keep-files 时保留） ----
if [[ $KEEP_FILES -eq 0 ]] && id "$SERVICE_USER" &>/dev/null; then
    info "删除系统用户 $SERVICE_USER ..."
    userdel -r "$SERVICE_USER" 2>/dev/null || userdel "$SERVICE_USER" 2>/dev/null || true
    info "用户已删除"
fi

# ---- 4. 清理 PAM sudo 配置 ----
PAM_FILE="/etc/pam.d/sudo"
if [[ -f "$PAM_FILE" ]] && grep -q "cert-sudo-check" "$PAM_FILE" 2>/dev/null; then
    info "清理 PAM sudo 配置..."
    # 还原备份（优先找 cert-operator 生成的备份，兼容新旧命名）
    BAK=$(ls -t "${PAM_FILE}.bak.cert-operator."* "${PAM_FILE}.bak."* 2>/dev/null | head -1)
    if [[ -n "$BAK" ]]; then
        cp "$BAK" "$PAM_FILE"
        info "已从备份恢复: $(basename "$BAK")"
        rm -f "$BAK"
    else
        # 无备份则删除 cert-operator 插入的 5 行（从注释到 pam_deny.so）
        sed -i '/^# cert-operator:/,/^auth requisite  pam_deny.so$/d' "$PAM_FILE"
        info "已移除 cert-operator PAM 配置"
    fi
fi

echo ""
echo -e "${GREEN}✅ 卸载完成${NC}"
echo ""
